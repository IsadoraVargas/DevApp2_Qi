import 'dart:math';

import 'package:flutter/material.dart';

void main(){
  runApp(MaterialApp(
      home: Home(),
      debugShowCheckedModeBanner: false;   //banner off
  ));
}

class Home extends StatefulWidget {
  const Home({ Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}
class _HomeState extends State<Home> {

  var _letras = [
    "Flutter",
    "Incrivel",
    "Dart",
  ];

  var _gerar = "Clique aqui para gerar as letras";

  void letrasGeradas(){
    var  randomico = Random().nextInt(3);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("papai noel"),
          backgroundColor: Colors.red,
        ),
        body: Container(
          width: double.infinity,
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
              border: Border.all(width: 3,color: Colors.green)
          ),
          child:Column(
              mainAxisAlignment: MainaxisAlingnment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.center

              children: <Widget>[
          Image.asset("imagens/logo.png"),
          Text(
            _gerar,
            textAlign: Textaling.center,
            style: TextStyle(
              fontSize: 22,
              fontStyle: FontStyle.normal,
              backgroundColor: Colors.blue,
            ),
          ),
          RaisedButton(
              child: Text("Clique aqui",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 22,
                    fontStyle:  ,
              )),
               color: Colors.blue,
               onPressed: letrasGeradas,
        ),
        ]),
    ),
    );
  }
}
