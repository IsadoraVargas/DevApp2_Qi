import'package:flutter/material.dart';
import'package:primeiro_app/CamposDart.dart';

void main(){
  runApp(MaterialApp(
    home: CamposDart(),
  ));
}
