import'package:flutter/material.dart';
import'package:primeiro_app/CamposDart.dart';
//import 'package:primeiro_app/atividade.dart';

void main(){

  runApp(MaterialApp(
    home: CamposDart(),
  ));
}
