import 'package:flutter/material.dart';
import 'dart:math';


void main(){
  runApp(MaterialApp(
    home: CamposDart(),
    debugShowCheckedModeBanner: false, //etiqueta apagada
  ));
}  //stf+enter

class CamposDart extends StatefulWidget {
  const CamposDart({Key? key}) : super(key: key);

  @override
  _CamposDartState createState() => _CamposDartState();
}

class _CamposDartState extends State<CamposDart> {

  var _letras=[
    "LOGADO",
  ];
  var _gerar = "Login";

  void letrasGeradas(){
    var randomico = Random().nextInt(1);
    setState(() {
      _gerar = _letras [randomico];
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Tela de login"),
        backgroundColor: Colors.lightBlue,
      ),
      body: Container(
        width: double.infinity,
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
            border: Border.all(width: 3,color: Colors.blueAccent)
        ),
        child: Column(
          //espaçamento de objetos
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,

          children: <Widget>[
            Image.asset("imagens/imggg.jpg"),
            //entrada de dados
            TextField(
              decoration: InputDecoration(labelText:"Email"),
              keyboardType: TextInputType.emailAddress,
            ),
            TextField(
              decoration: InputDecoration(labelText:"Senha"),
              keyboardType: TextInputType.text,
              obscureText: true,
            ),

            RaisedButton(
              child: Text("Logar", style: TextStyle(
                color:Colors.black54,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
              ),
              color: Colors.deepPurpleAccent,
              onPressed: letrasGeradas,
            ),
          ],
        ),
      ),
    );
  }
}