import 'dart:math';
import 'package:flutter/material.dart';

class atividade1 extends StatefulWidget {
  const atividade1({Key? key}) : super(key: key);

  @override
  _atividade1State createState() => _atividade1State();
}

class _atividade1State extends State<atividade1> {
  var _letras=[
    "VOLTOU",
  ];
  var _gerar = "back";
  void letrasGeradas(){
    var randomico = Random().nextInt(1);
    setState(() {
      _gerar = _letras [randomico];
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Imagem selecionada:"),
        backgroundColor: Colors.pink,
      ),
      body: Container(
          padding: EdgeInsets.all(120),
          decoration: BoxDecoration(
          border: Border.all(width: 10,color: Colors.pink),
          ),
        child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,

            children: <Widget> [
           Image.asset("imagens/espaco.png"),
           Padding(padding: EdgeInsets.only(top: 10),
          //ignore: deprecated_member_use
            child: RaisedButton(
            color: Colors.pinkAccent,
             textColor: Colors.white,
             child: Text("Voltar",
              style: TextStyle(fontSize: 20),
         ),
              onPressed: letrasGeradas,
       ),
      ),
     ]
    )
   ),
  );
 }
}

