import 'package:flutter/material.dart';
import 'package:pratica_layouts/atividade.dart';
import 'package:pratica_layouts/atividade1.dart';

  void main() {
  runApp(MaterialApp(
     home: atividade(),
    //home: atividade1(),
  ));
}



