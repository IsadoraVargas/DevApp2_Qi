package com.example.pratica_layouts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
