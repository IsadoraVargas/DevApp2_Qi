import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Harry(),
  ));
}

class Harry extends StatelessWidget {
  const Harry({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Bem vindo a Hogwarts"),
      ),
      body: Center(
        child: Column(
          children: <Widget> [
          Image.asset('imagens/wallpaper.jpg'),
          SizedBox(height: 20),
          Text("GUIA PARA ALUNOS DE HOGWARTS",
               style: TextStyle(
               fontSize: 20,
             )),
          SizedBox(height: 20),
          ElevatedButton(
            child: Text("Entrar no Salão Comunal",
              style: TextStyle(
              fontSize: 20,
             )),
            onPressed: () {
            Navigator.push(context,
            MaterialPageRoute(builder: (context) => SalaoComunal()),
        );
       },
      ),
     ],
    ),
   ),
  );
 }
}

class SalaoComunal extends StatelessWidget {
  const SalaoComunal({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Salão Comunal"),
      ),
      body: ListView(
        children: [
          ListTile(
            leading: Icon(Icons.house),
            title: Text("Guia das Casas"),
            onTap: () {
            Navigator.push(context,
            MaterialPageRoute(builder: (context) => Casas()));
            },
          ),
          ListTile(
            leading: Icon(Icons.map_outlined),
            title: Text('Mapa do Maroto'),
            onTap: (){
            Navigator.push(context,
            MaterialPageRoute(builder: (context) => MapaHog()));
            },
          ),
          ListTile(
            leading: Icon(Icons.collections_bookmark_outlined),
            title: Text("Lista de Livros"),
            onTap: (){
            Navigator.push(context,
            MaterialPageRoute(builder: (context) => Livros()));
            },
          ),
          ListTile(
            leading: Icon(Icons.access_alarm),
            title: Text("Horario das Aulas"),
            onTap: () {
            Navigator.push(context,
            MaterialPageRoute(builder: (context) => horaaula()));
              },
              ),
          ListTile(
            leading: Icon(Icons.sports_baseball_outlined),
            title: Text("Quadribol"),
            onTap: (){
            Navigator.push(context,
            MaterialPageRoute(builder: (context) => quadribol()));
            },
            ),
          SizedBox(height: 20),
          Image.asset('imagens/expresso.jpg'),
          SizedBox(height: 30),
          ElevatedButton(
            child: Text("voltar"),
            onPressed: () {
            Navigator.push(context,
            MaterialPageRoute(builder: (context) => Harry()),
       );
      },
     ),
    ],
   ),
  );
 }
}

class MapaHog extends StatelessWidget {
  const MapaHog({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("MAPA DE HOGWARTS"),
      ),
      body: Center(
        child: Column(
          children: <Widget> [
            Image.asset('imagens/mapa.jpg'),
            SizedBox(height: 20),
            ElevatedButton(
              child: Text("voltar"),
              onPressed: () {
              Navigator.push(context,
              MaterialPageRoute(builder: (context) => SalaoComunal()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class Livros extends StatelessWidget {
  const Livros({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("LISTA DE LIVROS LETIVOS"),
      ),
      body: Center(
        child: Column(
          children: <Widget> [
            Image.asset('imagens/livros.jpg'),
            SizedBox(height: 20),
            ElevatedButton(
              child: Text("voltar"),
              onPressed: () {
              Navigator.push(context,
              MaterialPageRoute(builder: (context) => SalaoComunal()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class Casas extends StatelessWidget {
  const Casas({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("CASAS DE HOGWARTS"),
      ),
      body: Center(
        child: Column(
          children: <Widget> [
            Image.asset('imagens/casas.png'),
                  Padding(padding: EdgeInsets.all(15),
                      child: Text("Lufa-Lufa: Empáticos, Otimistas e Sempre ajudam os amigos",
                      style: TextStyle(
                      fontSize: 15,
                      color: Colors.orange),
                  ),),
                  Padding(padding: EdgeInsets.all(15),
                      child: Text("Sonserina: Ambiciosos, Determinados e Nunca aceitam perder",
                      style: TextStyle(
                      fontSize: 15,
                      color: Colors.green),
                  ),),
                    Padding(padding: EdgeInsets.all(15),
                     child: Text("Grifinória: Corajosos, Competitivos e Nunca desistem fácil",
                     style: TextStyle(
                     fontSize: 15,
                     color: Colors.red),
                  ),),
                    Padding(padding: EdgeInsets.all(15),
                     child:  Text("Corvinal: Inteligentes ,Criativos e Sempre focados no objetivo",
                     style: TextStyle(
                     fontSize: 15,
                     color: Colors.blueAccent),
                  ),),
                      ElevatedButton(
                       child: Text("voltar"),
                       onPressed: () {
                      Navigator.push(context,
                         MaterialPageRoute(builder: (context) => SalaoComunal()),
               );
             },
           ),
         ],
        ),
      ),
    );
  }
}

class horaaula extends StatelessWidget {
  const horaaula({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("QUADRO DAS AULAS"),
      ),
      body: Center(
        child: Column(
          children: <Widget> [
            Image.asset('imagens/aulas.png'),
            SizedBox(height: 10),
            Image.asset('imagens/materiais.png'),
            SizedBox(height: 20),
            ElevatedButton(
              child: Text("voltar"),
              onPressed: () {
                Navigator.push(context,
                  MaterialPageRoute(builder: (context) => SalaoComunal()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class quadribol extends StatelessWidget {
  const quadribol({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("QUABRIBOL"),
      ),
      body: Center(
        child: Column(
          children: <Widget> [
            Image.asset('imagens/regras.png'),
            SizedBox(height: 10),
            Image.asset('imagens/times.jpeg'),
            SizedBox(height: 20),
            ElevatedButton(
              child: Text("voltar"),
              onPressed: () {
                Navigator.push(context,
                  MaterialPageRoute(builder: (context) => SalaoComunal()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}


