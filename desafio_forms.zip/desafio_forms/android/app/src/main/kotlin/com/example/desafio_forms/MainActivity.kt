package com.example.desafio_forms

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
