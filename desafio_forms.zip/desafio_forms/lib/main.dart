import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: MyForms(),
  ));
}

class MyForms extends StatefulWidget {
  const MyForms({Key? key}) : super(key: key);

  @override
  _MyFormsState createState() => _MyFormsState();
}

class _MyFormsState extends State<MyForms> {
  bool _selec = false;
  bool _enviar = false;

  @override
  Widget build(BuildContext context) {
  return Scaffold(
   appBar: AppBar(
    title: Text("Preencha o formulário"),
    backgroundColor: Colors.black,
   ),
   body: Container(
     child: Column(
     children: <Widget> [
       TextField(
         keyboardType: TextInputType.text,
         decoration: InputDecoration(
         icon: Icon(Icons.account_circle),
         labelText: 'Nome'),
     ),
        TextField(
        keyboardType: TextInputType.number,
         decoration: InputDecoration(
         icon: Icon(Icons.credit_card),
         labelText: 'Número do cartão'),
     ),
        TextField(
        keyboardType: TextInputType.datetime,
         decoration: InputDecoration(
         icon: Icon(Icons.calendar_today),
         labelText: 'Data de validade'),
     ),
        TextField(
        keyboardType: TextInputType.number,
         decoration: InputDecoration(
         icon: Icon(Icons.lock),
         labelText: 'Código de segurança'),
     ),
        TextField(
        keyboardType: TextInputType.text,
         decoration: InputDecoration(
         icon: Icon(Icons.card_membership_outlined),
         labelText: 'Apelido do cartão'),
            ),
         Text('Manter o cartão registrado'),
         Checkbox(
             value: _selec,
             onChanged: (_check)
             { setState((){
               if(_selec){ _selec = false; }else{ _selec = true; }
             });
             }),
       //ignore: deprecated_member_use
       RaisedButton(
         child: Text('Registrar',
         style: TextStyle(fontSize: 15, color: Colors.white, fontWeight: FontWeight.bold)),
         color: Colors.black,
         onPressed: (){
         if(_enviar){ _enviar= false; }else{ _enviar = true; }
          }),
          ],
        ),
      ),
    );
  }
}

