package com.example.projeto_final_grupo1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
