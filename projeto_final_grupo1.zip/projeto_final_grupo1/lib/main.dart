import 'package:flutter/material.dart';
import 'package:projeto_final_grupo1/Home.dart';
import 'package:projeto_final_grupo1/Login.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
   home: Login(),
  ));
}
